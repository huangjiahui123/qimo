from django.apps import AppConfig


class GalleryshowConfig(AppConfig):
    name = 'galleryshow'
